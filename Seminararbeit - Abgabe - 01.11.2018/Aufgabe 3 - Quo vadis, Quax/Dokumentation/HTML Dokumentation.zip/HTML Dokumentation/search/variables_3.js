var searchData=
[
  ['quadtreetime',['QuadtreeTime',['../class_algorithm_1_1_quadtree_1_1_quadtree_manager.html#a70468a3cf301151382e0c025ffa15345',1,'Algorithm::Quadtree::QuadtreeManager']]]
];
