var searchData=
[
  ['togglegui',['ToggleGUI',['../class_load_image_manager.html#a217710075957fc32fb1df798ddb7dce0',1,'LoadImageManager.ToggleGUI()'],['../class_options_manager.html#a256eb861137cc04f2cafc551d606579b',1,'OptionsManager.ToggleGUI()']]]
];
