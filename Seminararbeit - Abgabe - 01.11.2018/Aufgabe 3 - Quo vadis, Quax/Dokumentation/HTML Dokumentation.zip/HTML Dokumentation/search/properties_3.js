var searchData=
[
  ['instance',['Instance',['../class_algorithm_1_1_pathfinding_1_1_pathfinding_manager.html#aed91480d3ed995acdf67f2c4daf2d80e',1,'Algorithm.Pathfinding.PathfindingManager.Instance()'],['../class_algorithm_1_1_quadtree_1_1_quadtree_manager.html#a95d868db5abdb70acce60cf5a291e251',1,'Algorithm.Quadtree.QuadtreeManager.Instance()'],['../class_map_data_manager.html#a92caad8097c0fb80c15046451414457f',1,'MapDataManager.Instance()'],['../class_thread_queuer.html#ab5f5ef9ad37d332716ab1fb093bc565a',1,'ThreadQueuer.Instance()']]],
  ['isopen',['IsOpen',['../class_options_manager.html#a3a6244fed77ad1bf5840ca0ca20d2c89',1,'OptionsManager']]]
];
