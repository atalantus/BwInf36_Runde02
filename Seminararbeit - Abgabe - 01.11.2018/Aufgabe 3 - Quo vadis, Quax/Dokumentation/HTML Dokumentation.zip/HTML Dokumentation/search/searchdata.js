var indexSectionsWithContent =
{
  0: "acdefghilmnopqrstuvwxy",
  1: "aceghilmnopqstv",
  2: "au",
  3: "acefghimnoqrstu",
  4: "ghpqrtxy",
  5: "mn",
  6: "cdhimnpsw",
  7: "cfrsu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "properties",
  7: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Properties",
  7: "Events"
};

