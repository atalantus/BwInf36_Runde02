var searchData=
[
  ['optionsmanager',['OptionsManager',['../class_options_manager.html',1,'']]]
];
