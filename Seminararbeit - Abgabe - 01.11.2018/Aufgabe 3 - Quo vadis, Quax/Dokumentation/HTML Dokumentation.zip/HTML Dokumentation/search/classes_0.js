var searchData=
[
  ['algorithmmanager',['AlgorithmManager',['../class_algorithm_1_1_algorithm_manager.html',1,'Algorithm']]]
];
