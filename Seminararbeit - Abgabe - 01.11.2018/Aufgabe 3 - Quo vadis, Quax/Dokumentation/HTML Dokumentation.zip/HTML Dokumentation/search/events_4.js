var searchData=
[
  ['updatedquadtree',['UpdatedQuadtree',['../class_algorithm_1_1_quadtree_1_1_quadtree_manager.html#ac39a654c986c5741a50462b3427059f0',1,'Algorithm::Quadtree::QuadtreeManager']]]
];
