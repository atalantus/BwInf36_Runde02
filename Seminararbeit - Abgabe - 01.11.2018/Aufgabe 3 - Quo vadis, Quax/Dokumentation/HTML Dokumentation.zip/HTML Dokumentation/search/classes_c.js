var searchData=
[
  ['square',['Square',['../class_algorithm_1_1_quadtree_1_1_square.html',1,'Algorithm::Quadtree']]]
];
