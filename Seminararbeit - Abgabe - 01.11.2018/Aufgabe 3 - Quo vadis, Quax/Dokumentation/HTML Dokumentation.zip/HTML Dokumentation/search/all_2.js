var searchData=
[
  ['dimensions',['Dimensions',['../class_map_data_manager.html#a9c6e93a47a2d5319a0aa30478440fc72',1,'MapDataManager']]]
];
