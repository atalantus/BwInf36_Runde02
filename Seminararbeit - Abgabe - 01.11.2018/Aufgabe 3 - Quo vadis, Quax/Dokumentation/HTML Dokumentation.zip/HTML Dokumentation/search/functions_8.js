var searchData=
[
  ['node',['Node',['../class_algorithm_1_1_pathfinding_1_1_node.html#a5d346f1d79b1db5be5f591425774af26',1,'Algorithm.Pathfinding.Node.Node()'],['../class_algorithm_1_1_quadtree_1_1_node.html#adb3cd5a0c8aac37cb850f6724a291f6a',1,'Algorithm.Quadtree.Node.Node()']]]
];
