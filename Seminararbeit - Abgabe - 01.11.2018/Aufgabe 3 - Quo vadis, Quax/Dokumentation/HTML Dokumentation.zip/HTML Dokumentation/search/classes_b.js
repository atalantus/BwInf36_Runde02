var searchData=
[
  ['quadtreemanager',['QuadtreeManager',['../class_algorithm_1_1_quadtree_1_1_quadtree_manager.html',1,'Algorithm::Quadtree']]]
];
