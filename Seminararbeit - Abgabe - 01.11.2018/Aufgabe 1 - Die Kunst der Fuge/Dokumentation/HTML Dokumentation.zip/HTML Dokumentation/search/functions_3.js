var searchData=
[
  ['nextpossiblerowsum',['NextPossibleRowSum',['../struct_aufgabe1___die_kunst_der_fuge_1_1_next_possible_row_sum.html#adc1ec6d4b6fa581a0bbd328c83a1fed7',1,'Aufgabe1_DieKunstDerFuge::NextPossibleRowSum']]]
];
