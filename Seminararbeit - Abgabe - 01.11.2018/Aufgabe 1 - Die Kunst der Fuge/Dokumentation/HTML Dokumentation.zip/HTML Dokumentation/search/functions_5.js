var searchData=
[
  ['removelastbrick',['RemoveLastBrick',['../class_aufgabe1___die_kunst_der_fuge_1_1_row.html#abf696dbc6a240858db27610a71bf4294',1,'Aufgabe1_DieKunstDerFuge::Row']]],
  ['row',['Row',['../class_aufgabe1___die_kunst_der_fuge_1_1_row.html#a4c326684c8c7e0d430d87631b23384cf',1,'Aufgabe1_DieKunstDerFuge.Row.Row()'],['../class_aufgabe1___die_kunst_der_fuge_1_1_row.html#a71951ee2f16de8f225a563638a3b7c5a',1,'Aufgabe1_DieKunstDerFuge.Row.Row(int bricksPerRow)']]]
];
