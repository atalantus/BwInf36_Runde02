var searchData=
[
  ['nextpossiblerowsum',['NextPossibleRowSum',['../struct_aufgabe1___die_kunst_der_fuge_1_1_next_possible_row_sum.html',1,'Aufgabe1_DieKunstDerFuge']]]
];
