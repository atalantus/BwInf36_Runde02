var searchData=
[
  ['usedbrickindex',['UsedBrickIndex',['../struct_aufgabe1___die_kunst_der_fuge_1_1_next_possible_row_sum.html#a6f1d449623a47dda17bf5d4e4b3d2f29',1,'Aufgabe1_DieKunstDerFuge::NextPossibleRowSum']]],
  ['usedgapcount',['UsedGapCount',['../class_aufgabe1___die_kunst_der_fuge_1_1_wall_builder.html#ad01f43b8bd5eed34bf5e4c87ea2da7a9',1,'Aufgabe1_DieKunstDerFuge::WallBuilder']]]
];
