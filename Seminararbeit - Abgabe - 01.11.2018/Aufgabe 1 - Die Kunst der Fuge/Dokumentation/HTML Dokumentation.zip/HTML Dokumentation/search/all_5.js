var searchData=
[
  ['nextbricktoplace',['NextBrickToPlace',['../class_aufgabe1___die_kunst_der_fuge_1_1_row.html#af9d6c277e377f6bfddd0f5c7183073b5',1,'Aufgabe1_DieKunstDerFuge::Row']]],
  ['nextpossiblerowsum',['NextPossibleRowSum',['../struct_aufgabe1___die_kunst_der_fuge_1_1_next_possible_row_sum.html',1,'Aufgabe1_DieKunstDerFuge.NextPossibleRowSum'],['../struct_aufgabe1___die_kunst_der_fuge_1_1_next_possible_row_sum.html#adc1ec6d4b6fa581a0bbd328c83a1fed7',1,'Aufgabe1_DieKunstDerFuge.NextPossibleRowSum.NextPossibleRowSum()']]],
  ['nextpossiblerowsums',['NextPossibleRowSums',['../class_aufgabe1___die_kunst_der_fuge_1_1_row.html#a9bf5c5c8a710437d1c5a8517a22b6691',1,'Aufgabe1_DieKunstDerFuge::Row']]]
];
