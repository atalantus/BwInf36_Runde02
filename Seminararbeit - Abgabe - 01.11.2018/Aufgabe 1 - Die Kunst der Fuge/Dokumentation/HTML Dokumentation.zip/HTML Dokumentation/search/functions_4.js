var searchData=
[
  ['placenextbrick',['PlaceNextBrick',['../class_aufgabe1___die_kunst_der_fuge_1_1_row.html#a0140d2767b115d2bb21a3b277815a9ce',1,'Aufgabe1_DieKunstDerFuge::Row']]]
];
