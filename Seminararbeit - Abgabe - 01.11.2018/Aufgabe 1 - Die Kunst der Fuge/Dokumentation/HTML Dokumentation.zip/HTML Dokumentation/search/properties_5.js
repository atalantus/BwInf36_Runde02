var searchData=
[
  ['placedbricks',['PlacedBricks',['../class_aufgabe1___die_kunst_der_fuge_1_1_row.html#a021575f8ab40995abbf9e8cbc7bee236',1,'Aufgabe1_DieKunstDerFuge::Row']]],
  ['placedbricksindex',['PlacedBricksIndex',['../class_aufgabe1___die_kunst_der_fuge_1_1_row.html#a9de8a2d11929c3abb9b4866c59fdb0d9',1,'Aufgabe1_DieKunstDerFuge::Row']]],
  ['possiblerowsum',['PossibleRowSum',['../struct_aufgabe1___die_kunst_der_fuge_1_1_next_possible_row_sum.html#adc0b82b07368e8410daf43c627cf0bae',1,'Aufgabe1_DieKunstDerFuge::NextPossibleRowSum']]]
];
