var searchData=
[
  ['nextbricktoplace',['NextBrickToPlace',['../class_aufgabe1___die_kunst_der_fuge_1_1_row.html#af9d6c277e377f6bfddd0f5c7183073b5',1,'Aufgabe1_DieKunstDerFuge::Row']]],
  ['nextpossiblerowsums',['NextPossibleRowSums',['../class_aufgabe1___die_kunst_der_fuge_1_1_row.html#a9bf5c5c8a710437d1c5a8517a22b6691',1,'Aufgabe1_DieKunstDerFuge::Row']]]
];
